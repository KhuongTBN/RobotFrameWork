# HomePage locators
SearchTextBox = '//*[@id="gh-ac"]'
SearchButton = '//*[@id="gh-btn"]'

# Landing page locatiors
